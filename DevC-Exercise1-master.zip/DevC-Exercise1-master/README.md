# DevC JavaScript Development Course
Exercise 1
